import { setResponseHeaders, setResponseStatus, getHeaders, getQuery, sendError, createError, defineEventHandler, isPreflightRequest, handleCors } from 'h3';
import config from '../utils/config';
import { specificProxyRequest } from '../utils/proxy';
import { mp4ChunkManager } from '../utils/mp4-chunks';

// Check if MP4 proxying is disabled via config
const isMp4ProxyDisabled = () => config.DISABLE_MP4;

// HLS-like MP4 streaming configuration
const SEGMENT_SIZE = 4.5 * 1024 * 1024; // 4.5MB segments (close to 5MB as requested)
const MAX_SEGMENTS_PER_REQUEST = 3; // Limit segments per request to prevent bandwidth abuse

// Browser detection and compatibility
function detectBrowser(userAgent: string) {
  const ua = userAgent.toLowerCase();
  if (ua.includes('firefox')) return 'firefox';
  if (ua.includes('brave')) return 'brave';
  if (ua.includes('chrome') && !ua.includes('edg')) return 'chrome';
  if (ua.includes('safari') && !ua.includes('chrome')) return 'safari';
  return 'other';
}

// Get browser-specific headers
function getBrowserSpecificHeaders(browser: string, contentLength?: number, isChunked: boolean = false): Record<string, string> {
  const baseHeaders: Record<string, string> = {
    'Accept-Ranges': 'bytes',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Range, Content-Range, Content-Length, Content-Type',
    'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
    'Access-Control-Expose-Headers': 'Content-Range, Content-Length, Accept-Ranges',
    'Cache-Control': 'public, max-age=3600, immutable',
  };

  switch (browser) {
    case 'firefox':
      const firefoxHeaders: Record<string, string> = {
        ...baseHeaders,
        'Content-Type': 'video/mp4; codecs="avc1.42E01E,mp4a.40.2"',
        'X-Content-Duration': 'INFINITY',
        'Content-Disposition': 'inline; filename="video.mp4"',
      };

      // For chunked responses, don't set Content-Length to avoid conflicts with partial content
      if (!isChunked && contentLength) {
        firefoxHeaders['Content-Length'] = contentLength.toString();
      }

      return firefoxHeaders;
    case 'brave':
      return {
        ...baseHeaders,
        'Content-Type': 'video/mp4',
        'X-Content-Type-Options': 'nosniff',
        ...(contentLength && { 'Content-Length': contentLength.toString() }),
      };
    case 'safari':
      return {
        ...baseHeaders,
        'Content-Type': 'video/mp4',
        'X-Content-Type-Options': 'nosniff',
        ...(contentLength && { 'Content-Length': contentLength.toString() }),
      };
    default: // chrome and others
      return {
        ...baseHeaders,
        'Content-Type': 'video/mp4',
        'X-Content-Type-Options': 'nosniff',
        ...(contentLength && { 'Content-Length': contentLength.toString() }),
      };
  }
}

/**
 * Get HLS-like playlist/manifest for MP4 segments
 */
async function getMP4Playlist(event: any, url: string, headers: Record<string, string>) {
  try {
    // Get file size first
    const headResponse = await globalThis.fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        ...headers,
      }
    });

    if (!headResponse.ok) {
      throw new Error(`Failed to get MP4 info: ${headResponse.status} ${headResponse.statusText}`);
    }

    const contentLength = parseInt(headResponse.headers.get('content-length') || '0', 10);
    if (!contentLength) {
      throw new Error('Unable to determine MP4 file size');
    }

    const totalSegments = Math.ceil(contentLength / SEGMENT_SIZE);
    const segments = [];

    // Generate segment URLs (HLS-like format)
    for (let i = 0; i < totalSegments; i++) {
      const start = i * SEGMENT_SIZE;
      const end = Math.min(start + SEGMENT_SIZE - 1, contentLength - 1);
      const size = end - start + 1;

      segments.push({
        index: i,
        start,
        end,
        size,
        url: `/mp4-proxy?url=${encodeURIComponent(url)}&segment=${i}&headers=${encodeURIComponent(JSON.stringify(headers))}`
      });
    }

    const manifest = {
      url,
      totalSize: contentLength,
      segmentSize: SEGMENT_SIZE,
      totalSegments,
      segments,
      headers
    };

    const browser = detectBrowser(getHeaders(event)['user-agent'] || '');
    const responseHeaders = getBrowserSpecificHeaders(browser);

    setResponseHeaders(event, {
      ...responseHeaders,
      'Content-Type': 'application/json',
    });

    return manifest;
  } catch (error: any) {
    console.error('Error generating MP4 playlist:', error);
    throw error;
  }
}

/**
 * Get a specific MP4 segment (4.5MB chunks)
 */
async function getMP4Segment(event: any, url: string, segmentIndex: number, headers: Record<string, string>) {
  try {
    // Get file size first
    const headResponse = await globalThis.fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        ...headers,
      }
    });

    if (!headResponse.ok) {
      throw new Error(`Failed to get MP4 info: ${headResponse.status} ${headResponse.statusText}`);
    }

    const totalSize = parseInt(headResponse.headers.get('content-length') || '0', 10);
    if (!totalSize) {
      throw new Error('Unable to determine MP4 file size');
    }

    // Calculate segment range
    const start = segmentIndex * SEGMENT_SIZE;
    const end = Math.min(start + SEGMENT_SIZE - 1, totalSize - 1);
    const range = `bytes=${start}-${end}`;

    // Fetch the segment
    const response = await globalThis.fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        'Range': range,
        ...headers,
      }
    });

    if (!response.ok && response.status !== 206) {
      throw new Error(`Failed to fetch MP4 segment: ${response.status} ${response.statusText}`);
    }

    const segmentData = new Uint8Array(await response.arrayBuffer());
    const browser = detectBrowser(getHeaders(event)['user-agent'] || '');
    const responseHeaders = getBrowserSpecificHeaders(browser, segmentData.length, false);

    setResponseHeaders(event, {
      ...responseHeaders,
      'Content-Range': `bytes ${start}-${end}/${totalSize}`,
      'X-Segment-Index': segmentIndex.toString(),
      'X-Segment-Start': start.toString(),
      'X-Segment-End': end.toString(),
    });

    setResponseStatus(event, 206);
    return segmentData;
  } catch (error: any) {
    console.error('Error fetching MP4 segment:', error);
    throw error;
  }
}

/**
 * Handle progressive streaming (serves multiple segments at once)
 */
async function getMP4Progressive(event: any, url: string, headers: Record<string, string>, startSegment: number = 0) {
  try {
    // Get file size first
    const headResponse = await globalThis.fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        ...headers,
      }
    });

    if (!headResponse.ok) {
      throw new Error(`Failed to get MP4 info: ${headResponse.status} ${headResponse.statusText}`);
    }

    const totalSize = parseInt(headResponse.headers.get('content-length') || '0', 10);
    if (!totalSize) {
      throw new Error('Unable to determine MP4 file size');
    }

    const totalSegments = Math.ceil(totalSize / SEGMENT_SIZE);
    const segmentsToServe = Math.min(MAX_SEGMENTS_PER_REQUEST, totalSegments - startSegment);

    const segmentBuffers: Uint8Array[] = [];

    // Fetch segments sequentially
    for (let i = 0; i < segmentsToServe; i++) {
      const segmentIndex = startSegment + i;
      const start = segmentIndex * SEGMENT_SIZE;
      const end = Math.min(start + SEGMENT_SIZE - 1, totalSize - 1);
      const range = `bytes=${start}-${end}`;

      const response = await globalThis.fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
          'Range': range,
          ...headers,
        }
      });

      if (!response.ok && response.status !== 206) {
        console.warn(`Failed to fetch segment ${segmentIndex}, stopping progressive stream`);
        break;
      }

      const segmentData = new Uint8Array(await response.arrayBuffer());
      segmentBuffers.push(segmentData);
    }

    // Combine all segments
    const totalLength = segmentBuffers.reduce((sum, buf) => sum + buf.length, 0);
    const combinedData = new Uint8Array(totalLength);

    let offset = 0;
    for (const segment of segmentBuffers) {
      combinedData.set(segment, offset);
      offset += segment.length;
    }

    const browser = detectBrowser(getHeaders(event)['user-agent'] || '');
    const responseHeaders = getBrowserSpecificHeaders(browser, combinedData.length, false);

    setResponseHeaders(event, {
      ...responseHeaders,
      'X-Start-Segment': startSegment.toString(),
      'X-Segments-Served': segmentBuffers.length.toString(),
      'X-Total-Segments': totalSegments.toString(),
    });

    return combinedData;
  } catch (error: any) {
    console.error('Error in progressive streaming:', error);
    throw error;
  }
}

/**
 * Handle chunked MP4 streaming (serves individual chunks)
 */
async function handleChunkedRequest(event: any, url: string, headers: Record<string, string>) {
  try {
    // Get file size first
    const headResponse = await globalThis.fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        ...headers,
      }
    });

    if (!headResponse.ok) {
      throw new Error(`Failed to get MP4 info: ${headResponse.status} ${headResponse.statusText}`);
    }

    const totalSize = parseInt(headResponse.headers.get('content-length') || '0', 10);
    if (!totalSize) {
      throw new Error('Unable to determine MP4 file size');
    }

    let chunkIndex = mp4ChunkManager.parseChunkIndex(event);
    let start: number, end: number;
    const browser = detectBrowser(getHeaders(event)['user-agent'] || '');
    // Use browser-specific chunk sizes to avoid MP4 corruption
    let chunkSize: number;
    if (browser === 'firefox') {
      chunkSize = 200 * 1024 * 1024; // 200MB for Firefox
    } else if (browser === 'brave') {
      chunkSize = 4 * 1024 * 1024; // 4MB for Brave
    } else {
      chunkSize = 5 * 1024 * 1024; // 5MB default for others (Chrome, Safari, etc.)
    }

    if (chunkIndex === null) {
      // Check if there's a Range header for seeking
      const rangeHeader = getHeaders(event)['range'] || getHeaders(event)['Range'];
      if (rangeHeader && rangeHeader.startsWith('bytes=')) {
        const rangeMatch = rangeHeader.match(/bytes=(\d+)-(\d*)/);
        if (rangeMatch) {
          start = parseInt(rangeMatch[1], 10);
          const endStr = rangeMatch[2];

          // Respect the browser's exact range request for proper MP4 streaming
          end = endStr ? parseInt(endStr, 10) : Math.min(start + chunkSize - 1, totalSize - 1); // Use browser-specific chunk size
        } else {
          // Invalid range, start from beginning with headers
          start = 0;
          end = Math.min(2 * 1024 * 1024 - 1, totalSize - 1); // 2MB for headers
        }
      } else {
        // No range header, start from beginning with headers
        start = 0;
        end = Math.min(2 * 1024 * 1024 - 1, totalSize - 1); // 2MB for headers
      }
    } else {
      // Specific chunk requested
      start = chunkIndex * chunkSize;
      end = Math.min(start + chunkSize - 1, totalSize - 1);
    }

    const range = `bytes=${start}-${end}`;

    const response = await globalThis.fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
        'Range': range,
        ...headers,
      }
    });

    if (!response.ok && response.status !== 206) {
      throw new Error(`Failed to fetch MP4 chunk: ${response.status} ${response.statusText}`);
    }

    const chunkData = new Uint8Array(await response.arrayBuffer());
    const responseHeaders = getBrowserSpecificHeaders(browser, chunkData.length, true);

    setResponseHeaders(event, {
      ...responseHeaders,
      'Content-Range': `bytes ${start}-${end}/${totalSize}`,
      'X-Chunked-Response': 'true',
      ...(chunkIndex !== null && { 'X-Chunk-Index': chunkIndex.toString() }),
    });

    setResponseStatus(event, 206);
    return chunkData;
  } catch (error: any) {
    console.error('Error in chunked streaming:', error);
    throw error;
  }
}

/**
 * Handle regular MP4 proxying with browser-specific optimizations
 */
async function proxyMP4(event: any) {
  const url = getQuery(event).url as string;
  const headersParam = getQuery(event).headers as string;

  if (!url) {
    return sendError(event, createError({
      statusCode: 400,
      statusMessage: 'URL parameter is required'
    }));
  }

  let headers = {};
  try {
    headers = headersParam ? JSON.parse(headersParam) : {};
  } catch (e) {
    return sendError(event, createError({
      statusCode: 400,
      statusMessage: 'Invalid headers format'
    }));
  }

  try {
    const requestHeaders = getHeaders(event);
    const rangeHeader = requestHeaders['range'] || requestHeaders['Range'];
    const browser = detectBrowser(requestHeaders['user-agent'] || '');

    const fetchHeaders: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0',
      ...(headers as Record<string, string>),
    };

    // Forward Range header if present
    if (rangeHeader) {
      fetchHeaders['Range'] = rangeHeader;
    }

    // Add browser-specific headers
    if (browser === 'firefox') {
      fetchHeaders['Accept'] = 'video/mp4,video/*,*/*;q=0.1';
      fetchHeaders['Connection'] = 'keep-alive';
    } else if (browser === 'safari') {
      fetchHeaders['Accept'] = 'video/mp4,video/*,*/*;q=0.9';
      fetchHeaders['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15';
    }

    await specificProxyRequest(event, url, {
      fetchOptions: {
        method: 'GET',
        headers: fetchHeaders,
        redirect: 'follow',
      },
      onResponse(outputEvent, response) {
        const contentLength = parseInt(response.headers.get('content-length') || '0', 10);
        const contentRange = response.headers.get('content-range');
        const isPartialContent = response.status === 206;

        const responseHeaders = getBrowserSpecificHeaders(browser, contentLength, false);

        if (isPartialContent && contentRange) {
          responseHeaders['Content-Range'] = contentRange;
          setResponseStatus(outputEvent, 206);
        } else {
          // Ensure Accept-Ranges for seeking
          responseHeaders['Accept-Ranges'] = 'bytes';
          setResponseStatus(outputEvent, 200);
        }

        setResponseHeaders(outputEvent, responseHeaders);
      },
    });
  } catch (error: any) {
    console.error('Error proxying MP4:', error);
    return sendError(event, createError({
      statusCode: error.response?.status || 500,
      statusMessage: error.message || 'Error proxying MP4 file'
    }));
  }
}

export default defineEventHandler(async (event) => {
  // Handle CORS preflight requests
  if (isPreflightRequest(event)) return handleCors(event, {});

  if (isMp4ProxyDisabled()) {
    return sendError(event, createError({
      statusCode: 404,
      statusMessage: 'MP4 proxying is disabled'
    }));
  }

  // Block Firefox users
  const browser = detectBrowser(getHeaders(event)['user-agent'] || '');
  if (browser === 'firefox') {
    return sendError(event, createError({
      statusCode: 403,
      statusMessage: 'Firefox users are not allowed to access this service due to browser compatibility issues'
    }));
  }

  const url = getQuery(event).url as string;
  const headersParam = getQuery(event).headers as string;

  if (!url) {
    return sendError(event, createError({
      statusCode: 400,
      statusMessage: 'URL parameter is required'
    }));
  }

  let headers = {};
  try {
    headers = headersParam ? JSON.parse(headersParam) : {};
  } catch (e) {
    return sendError(event, createError({
      statusCode: 400,
      statusMessage: 'Invalid headers format'
    }));
  }

  try {
    // Handle HEAD requests
    if (event.method === 'HEAD') {
      return await proxyMP4(event);
    }

    // Handle different streaming modes
    const segmentIndex = getQuery(event).segment;
    const progressive = getQuery(event).progressive;
    const playlist = getQuery(event).playlist;
    const chunked = getQuery(event).chunked;
    const browser = detectBrowser(getHeaders(event)['user-agent'] || '');

    if (chunked === 'true' || chunked === '') {
      // Chunked streaming (individual chunks)
      return await handleChunkedRequest(event, url, headers as Record<string, string>);
    }

    if (playlist === 'true' || playlist === '') {
      // Return HLS-like playlist
      return await getMP4Playlist(event, url, headers as Record<string, string>);
    }

    if (segmentIndex !== undefined) {
      // Return specific segment
      const index = parseInt(segmentIndex as string, 10);
      if (isNaN(index)) {
        return sendError(event, createError({
          statusCode: 400,
          statusMessage: 'Invalid segment index'
        }));
      }
      return await getMP4Segment(event, url, index, headers as Record<string, string>);
    }

    if (progressive === 'true' || progressive === '') {
      // Progressive streaming (multiple segments)
      const startSegment = parseInt((getQuery(event).start as string) || '0', 10);
      return await getMP4Progressive(event, url, headers as Record<string, string>, startSegment);
    }

    // Default: Auto-play with progressive streaming (starts playing immediately)
    // This makes it work like a regular video URL
    const startSegment = parseInt((getQuery(event).start as string) || '0', 10);
    return await getMP4Progressive(event, url, headers as Record<string, string>, startSegment);
  } catch (error: any) {
    console.error('Error in MP4 proxy handler:', error);
    return sendError(event, createError({
      statusCode: error.response?.status || 500,
      statusMessage: error.message || 'Error processing MP4 request'
    }));
  }
});